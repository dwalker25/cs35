

function main(){

}

$(document).ready(main());