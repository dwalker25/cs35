#
# hw0pr2.py ~ rolodex analysis
#
# Name(s):
#

#
# be sure your file runs from this location, 
# at the level containing all of the "phonebook" directories
#

import os
import os.path
import shutil

def how_many_txt_files(path):
    """ walks a whole directory structure
        and returns how many txt files are in it!

        call it with: how_many_txt_files(".")

        the (v1) (v2) etc. are different versions, to illustrate
        the process of _trying things out_ and _taking small steps_
    """
    #return 42  # just to check that it's working (v1)    

    AllFiles = list(os.walk(path))
    # print(AllFiles)    # just to check out what's up (v2)

    print("AllFiles has length: ", len(AllFiles), "\n")

    count = 0
    for item in AllFiles:
        # print("item is", item, "\n")    (v3)
        foldername, LoDirs, LoFiles = item   # cool unpacking!
        print("In", foldername, "there are", end=" ")

        for filename in LoFiles:
            if filename[-3:] == "txt":
                count += 1
        print(count, ".txt files found.")

    return count   # this is not _yet_ correct!

#
# when exploring, keep your data close (and your loops closer!)
#
if True:
    """ overall script that runs examples """

    # sign on
    print(f"[[ Start! ]]\n")

    # let's see what os.walk does
    walk_result = list(os.walk("."))
    print(walk_result)

    # let's see how many txt files there are...
    # num_txt_files = how_many_txt_files(".")
    # print("num_txt_files in . is", num_txt_files)

    # for i in range(1,9):
    #     try: 
    #         f = open(f"phone_files/07/0{i}.txt","r")
    #         fulltext = f.read()
    #         print(fulltext) 
    #         f.close()
    #     except FileNotFoundError as e:
    #         print(e)
    #         import sys     # to exit
    #         sys.exit(0)    # bye!!

    # sign off
    print("\n[[ Fin. ]]")








